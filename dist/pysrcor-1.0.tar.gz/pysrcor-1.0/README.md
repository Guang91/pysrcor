# pysrcor 

Python3 version of the ["srcor" function](https://idlastro.gsfc.nasa.gov/ftp/pro/idlphot/srcor.pro) in [NASA's IDL Astronomy User's Library](https://idlastro.gsfc.nasa.gov/contents.html)

A quick and easy function to correlate source positions from two catalogs.
